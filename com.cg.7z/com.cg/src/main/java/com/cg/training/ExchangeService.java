package com.cg.training;

public interface ExchangeService {
	
	public double getExchangeRate();

}
